package team.twenty;
public class Main {

    private Main(){
        //stub for stablility
    }

    public static void main(String[] args) {
        BillView view = new BillView();
        view.printAll();
    }
}
